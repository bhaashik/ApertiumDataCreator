Conjctn
aba
aba
