package morphology.cli;

import morphology.parser.MonodixBuilder;

public class Main {
    public static void main(String[] args) throws Exception {
        if (args.length != 4) {
            System.out.println("Usage: java Main <paradigm_dir> <lexicon_file> <feature_file> <output_dix>");
            return;
        }
        MonodixBuilder builder = new MonodixBuilder(args[0], args[1], args[2]);
        builder.build(args[3]);
        System.out.println("Monodix generation complete: " + args[3]);
    }
}