package morphology.parser;

import java.io.File;
import java.io.FileWriter;
import java.util.List;
import morphology.model.*;
import morphology.writer.DixWriter;

public class MonodixBuilder {
    private String paradigmDir;
    private String lexiconFile;
    private String featureFile;

    public MonodixBuilder(String paradigmDir, String lexiconFile, String featureFile) {
        this.paradigmDir = paradigmDir;
        this.lexiconFile = lexiconFile;
        this.featureFile = featureFile;
    }

    public void build(String outputFilePath) throws Exception {
        List<ParadigmCategory> categories = ParadigmParser.parseAll(paradigmDir);
        List<LexiconEntry> lexicon = LexiconParser.parse(lexiconFile);
        FeatureStructureMap fsMap = FeatureStructureParser.parse(featureFile);
        DixWriter.write(outputFilePath, categories, lexicon, fsMap);
    }
}