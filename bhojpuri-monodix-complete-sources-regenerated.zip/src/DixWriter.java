package morphology.writer;

import java.io.FileWriter;
import java.util.List;
import morphology.model.*;

public class DixWriter {
    public static void write(String filePath, List<ParadigmCategory> categories,
                             List<LexiconEntry> lexicon, FeatureStructureMap fsMap) throws Exception {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
            writer.write("<dictionary>\n");
            writer.write("  <alphabet>abcdefghijklmnopqrstuvwxyz</alphabet>\n");
            writer.write("  <pardefs>\n");
            for (ParadigmCategory cat : categories) {
                writer.write(cat.toDixFormat());
            }
            writer.write("  </pardefs>\n");
            writer.write("  <section id=\"main\">\n");
            for (LexiconEntry entry : lexicon) {
                writer.write(entry.toDixEntry(fsMap));
            }
            writer.write("  </section>\n");
            writer.write("</dictionary>\n");
        }
    }
}