package morphology.parser;

import java.io.*;
import java.util.*;
import morphology.model.LexiconEntry;

public class LexiconParser {
    public List<LexiconEntry> parse(File file) throws IOException {
        List<LexiconEntry> entries = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.replaceAll(""", "").split(",");
            if (parts.length >= 4) {
                String lemma = parts[0].trim();
                String paradigm = parts[2].trim();
                String category = parts[3].trim();
                entries.add(new LexiconEntry(lemma, paradigm, category));
            }
        }
        return entries;
    }
}