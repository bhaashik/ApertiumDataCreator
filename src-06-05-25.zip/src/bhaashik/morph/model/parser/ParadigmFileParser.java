package bhaashik.morph.model.parser;

import bhaashik.morph.model.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ParadigmFileParser {
    public ParadigmCategory parse(File file) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(file));
        String categoryName = br.readLine().trim();
        ParadigmCategory category = new ParadigmCategory(categoryName);
        List<String> lines = br.lines().filter(line -> !line.trim().isEmpty()).toList();

        int index = 0;
        while (index < lines.size()) {
            String lemma = lines.get(index++).trim();
            List<String> forms = new ArrayList<>();
            for (int i = 0; i < 4 && index < lines.size(); i++) {
                forms.add(lines.get(index++).trim());
            }
            category.addParadigm(new Paradigm(lemma, forms));
        }
        return category;
    }
}