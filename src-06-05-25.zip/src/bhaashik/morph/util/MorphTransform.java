package bhaashik.morph.util;

public class MorphTransform {
    private final String lemma;
    private final String form;
    private final String suffix;

    public MorphTransform(String lemma, String form) {
        this.lemma = lemma;
        this.form = form;
        this.suffix = extractSuffix(lemma, form);
    }

    private String extractSuffix(String lemma, String form) {
        if (form.startsWith(lemma)) {
            return form.substring(lemma.length());
        }
        return "";
    }

    public String getLemma() { return lemma; }
    public String getForm() { return form; }
    public String getSuffix() { return suffix; }

    public String toDixPElement() {
        return "<p><l>" + lemma + "</l><r>" + suffix + "</r></p>";
    }
}